#include <ctime>
#include "Game.h"

int TEST_MODE = 0;
// 0 : normal play
// 1 : only 1 Sydney test
// 2 : only 1 Alex test
// 3 : only 1 Basic test

bool getYN()
{
    char c;
    while (true)
    {
        std::cin >> c;
        if (c == 'y' || c == 'n')
            break;
    }
    if (c == 'y')
        return true;
    return false;
}

void Game::run()
{
    unsigned int num_of_human = 0;
    unsigned int num_of_computer = 0;
    unsigned int i;
    bool soft17 = false;
    bool blackjack65 = false;
    srand((unsigned int)time(NULL)); // To select a pseudo random set of deck everytime you play
    std::cout << "------------- Begin Game -------------" << std::endl;

    std::cout << "Do you enable Soft-17? (y/n)" << std::endl;

    soft17 = getYN();

    std::cout << "Do you enable 6:5 Blackjack? (y/n)" << std::endl;
    blackjack65 = getYN();

    if (TEST_MODE == 1) // For Sydney
    {
        std::string name;
        Player player(1);
        name = "Sydney";
        player.setName(name);
        players.push_back(player); // Enter player into the game
    }
    else if (TEST_MODE == 2) //For Alex
    {
        std::string name;
        Player player(2);
        name = "Alex";
        player.setName(name);
        players.push_back(player); // Enter player into the game
    }
    else if (TEST_MODE == 3) //For Basic
    {
        std::string name;
        Player player(3);
        name = "Basic";
        player.setName(name);
        players.push_back(player); // Enter player into the game
    }
    else // For normal play
    {
        std::cout << "How many human players?" <<std:: endl;
        std::cin >> num_of_human;

        std::cout << "How many computer players?" << std::endl;
        std::cin >> num_of_computer;

        for (i = 0; i < num_of_human; i++)
        {
            Player player(0);
            std::cout << "Human player " << i + 1 << " name: ";
            std::string name;
            std::cin >> name; //Get the name of the player
            player.setName(name); //Set the name of the player
            players.push_back(player);// Enter player into the game
        }

        for (i = 0; i < num_of_computer; i++)
        {
            int kind = rand() % 3 + 1; //This will chose alex/sidney/basic
            std::string name;
            Player player(kind);
            if (kind == 1)
                name = "Sydney" + std::to_string(i + 1);
            else if (kind == 2)
                name = "Alex" + std::to_string(i + 1);
            else
                name = "Basic" + std::to_string(i + 1);
            player.setName(name);

            players.push_back(player);
        }
    }
    while (true)
    {
        deck.shuffle(); //Shuffle the deck
        for (i = 0; i < players.size(); i++)
            players[i].init(); //Initialize Players
        house.init(); //Initialize the house (dealer)

        // Set bet money
        for (i = 0; i < players.size(); i++)
            players[i].bet();

        std::cout << "---------------- Deal ----------------" << std::endl;
        std::cout << "Let's deal some cards!" << std::endl;
        house.insertHand(deck.getCard()); // Insert card one for house
        house.insertHand(deck.getCard()); // Insert card two for house
        house.print(false);

        for (i = 0; i < players.size(); i++) //deal two cards for each player
        {
            players[i].insertHand(deck.getCard()); //Insert card one for player
            players[i].insertHand(deck.getCard()); // Insert card two for player
            players[i].print();
        }
        Card dealerCard = house.getFaceupCard();
        if (dealerCard.getNum() == 1)		// Ask Insurance for Bet
        {
            for (i = 0; i < players.size(); i++)
            {
                if (players[i].getKind() != 0)
                    continue;
                std::cout << "Do you want to Insure your bet? (y/n)" << std::endl;
                if (getYN())
                    players[i].insuranceBet(); // Take an additional bet amount equal to half of the original

            }
        }

        // Check if house has Blackjack
        if (house.checkBlackjack())
        {
            for (i = 0; i < players.size(); i++)
                players[i].checkResult(0);
        }
        else
        {
            std::cout << "-------------------------------------" << std::endl;
            for (i = 0; i < players.size(); i++)
            {
                players[i].print();
                if (players[i].getKind() == 0) // If it is a human player
                {
                    std::cout << "Do you want to enable Doubling Down? (y/n)" << std::endl;
                    if (getYN()) // Checks for doubling down and inserts a card
                    {
                        players[i].doDoublingDown();
                        std::cout << players[i].getName() << " do Doubling Down.\n" << std::endl;
                        players[i].insertHand(deck.getCard());
                        players[i].print(); //Displays the hand with the new card as well
                    }

                    std::cout << "Do you want to surrender? (y/n)" << std::endl;
                    if (getYN()) //Checks for surrendring
                    {
                        players[i].surrendering();
                        continue;
                    }
                }
                //Busted when the player has card value more than 21
                while (players[i].makeDecision(dealerCard) == 1)
                {
                    players[i].insertHand(deck.getCard());
                    players[i].print();
                    if (players[i].getScore() > 21)
                    {
                        std::cout << players[i].getName() << " is bust!" << std::endl;
                        break;
                    }
                }
                if (players[i].getScore() > 21)
                    std::cout << players[i].getName() << " has: BUSTED!" << std::endl;
                else
                    std::cout << players[i].getName() << " has: " << players[i].getScore() << std::endl;
                std::cout << "-------------------------------------" << std::endl;
            }
            house.print(true);
            while (house.makeDecision() == 1)
            {
                house.insertHand(deck.getCard());
                house.print(true);
                if (house.getScore() > 21)
                {
                    std::cout << "Dealer is bust!" << std::endl;
                    break;
                }
            }
            std::cout << "-------------------------------------" << std::endl;
            for (i = 0; i < players.size(); i++)
            {
                int dealerScore = house.getScore();
                players[i].checkResult(dealerScore);
            }
        }

        std::cout << "-------------- End Game -------------" << std::endl;
        std::cout << "Play again (y/n)?";
        if (!getYN())
            break;
    }
}