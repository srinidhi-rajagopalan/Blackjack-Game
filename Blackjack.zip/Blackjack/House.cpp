#include "House.h"

void House::init()
{	
	hand.init(); //Initializing the Hand
}

void House::setSoft17(bool soft17)
{
	this->soft17 = soft17; // Setting the variable soft17 with the value of the local variable here
}

void House::insertHand(Card card)
{
	hand.insert(card); //Deals card for a hand
}

bool House::checkBlackjack()
{
	return hand.checkBlackjack(); //Checks for blackjack in a hand
}

Card House::getFaceupCard() // Dealer has two cards, can only see one card during the game (card indexed 1)
{
	return hand.getCard(1);
}

void House::print(bool showAll)
{
	int score = 0;
	int num_of_ace = 0;
	std::cout << "Dealer:  \t";
	for (int i = 0; i < (int)hand.getCount(); i++) // Prints the dealer's hand
	{
		if (!showAll && i == 0) // For i=0 will print XX, for i=1 will print the card
		{
			std::cout << "XX ";
			continue;
		}
		std::cout << hand.getCard(i).getCard() << " ";

		if (showAll)
		{
			if (hand.getCard(i).getNum() == 11 || hand.getCard(i).getNum() == 12 || hand.getCard(i).getNum() == 13)
				score += 10; //For jack,queen and king add 10 to the score
			else
				score += hand.getCard(i).getNum(); // Else simply add the card number
			if (hand.getCard(i).getNum() == 1)
				num_of_ace++; // Finds out the number of aces in a hand
		}
	}
	if (showAll) //After the dealer sticks
	{
		if (num_of_ace > 0) // For printing the dealer's score
			std::cout << "   (" << score << " or " << score + num_of_ace * 10 << ")";
		else
			std::cout << "   (" << score << ")";
	}
	std::cout << std::endl;

}

int House::getScore()
{
	int score = 0;
	int num_of_ace = 0;
	for (int i = 0; i < hand.getCount(); i++)
	{
		if (hand.getCard(i).getNum() == 11 || hand.getCard(i).getNum() == 12 || hand.getCard(i).getNum() == 13)
			score += 10;
		else
			score += hand.getCard(i).getNum();
		if (hand.getCard(i).getNum() == 1)
			num_of_ace++;
	}
	if (num_of_ace > 0 && score + num_of_ace * 10 <= 21) // To decide if ace is 1 or 11:
		score = score + num_of_ace * 10; // Ace is 11 if score is less than 21
	return score;
}

int House::makeDecision()
{
	int res = 0;
	if (getScore() < 17)
		res = 1;	// hit
	else if (soft17 && ((hand.getCard(0).getNum() == 1 && hand.getCard(1).getNum() == 6) ||
		(hand.getCard(1).getNum() == 1 && hand.getCard(0).getNum() == 6)))
		res = 1;	// hit/ if soft 17 is enabled and house has a total value of 17
	else
		res = 0;	// stick

	if (res == 0)
		std::cout << "Dealer sticks!" << std::endl;
	else
		std::cout << "Dealer hits!" << std::endl;
	return res;
}