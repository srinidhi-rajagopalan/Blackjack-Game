#include "Player.h"

Player::Player(int kind)
{
    this->kind = kind; // human player/sidney/alex/basic
    bank_roll = 1000; // The total money each player has
  }

void Player::init() //A simple initialiser
{
    surrendered = false;
    doublingDown = false;
    bet_money = 0;
    insurance = 0;
    hand.init();
}

int Player::bet()
{
    if (kind == 0)	// Human
    {
        std::cout << "How much do you want to bet? (1-10)" << std::endl;
        std::cin >> bet_money;
    }
    else
    {
        bet_money = 5;//is this bet money for the computer players alex, sidney and basic
    }
    if (bet_money > 10)
        bet_money = 10;
    if (bet_money > bank_roll)
        bet_money = bank_roll; // this is included just to avoid any abstract problems if bet money is more than 10$
    std::cout << getName() << " bet $" << bet_money << std::endl;
    bank_roll -= bet_money;
    return bet_money;
}

void Player::setName(std::string name)
{
    this->name = name;
}

std::string Player::getName()
{
    return name;
}

int Player::getKind()
{
    return kind;
}
void Player::surrendering()
{
    surrendered = true;
}
void Player::insuranceBet() // Will insure that the player gets half the money in case he/she loses (only set for
{                           // human player, not for the computer players
    insurance = (int)round(bet_money / 2.0);
    bank_roll -= insurance;

    std::cout << getName() << " insure the bet." << std::endl;
}

void Player::doDoublingDown()
{
    doublingDown = true;
    bet_money += bet_money;
    bank_roll -= bet_money;
}

void Player::insertHand(Card card)
{
    hand.insert(card);
}

bool Player::checkBlackjack()
{
    return hand.checkBlackjack();
}

void Player::print()
{
    int score = 0;
    int num_of_ace = 0;
    std::cout << name << ":\t";
    if (name.length() < 7) // This is to ensure the name doesn't go out of the game format. Included this as
        std::cout << "\t"; // I have a long name: Srinidhi Rajagopalan
    for (int i = 0; i < (int)hand.getCount(); i++)
    {
        std::cout << hand.getCard(i).getCard() << " ";
        if (hand.getCard(i).getNum() == 11 || hand.getCard(i).getNum() == 12 || hand.getCard(i).getNum() == 13)
        {
            if (doublingDown && i < 2 )
                score += 5;
            else
                score += 10;
        }
        else
        {
            if (doublingDown && i < 2)
                score += hand.getCard(i).getNum() / 2;
            else
                score += hand.getCard(i).getNum();
        }
        if (hand.getCard(i).getNum() == 1)
            num_of_ace++;
    }
    if (num_of_ace > 0)
        std::cout << "(" << score << " or " << score + num_of_ace * 10 << ")" << std::endl;
    else
        std::cout << "(" << score << ")" << std::endl;
}

int Player::getScore()
{
    int score = 0;
    int num_of_ace = 0;
    for (int i = 0; i < hand.getCount(); i++)
    {
        if (hand.getCard(i).getNum() == 11 || hand.getCard(i).getNum() == 12 || hand.getCard(i).getNum() == 13)
        {
            if (doublingDown && i < 2)
                score += 5;
            else
                score += 10;
        }
        else
        {
            if (doublingDown && i < 2)
                score += hand.getCard(i).getNum() / 2;
            else
                score += hand.getCard(i).getNum();
        }
        if (hand.getCard(i).getNum() == 1)
            num_of_ace++;
    }
    if (num_of_ace > 0 && score + num_of_ace * 10 <= 21)
        score = score + num_of_ace * 10;
    return score;
}

int Player::makeDecision(Card dealerCard)
{
    int res = 0;
    if (kind == 0)	// Human
    {
        std::cout << "Do you want to hit(y/n)?";
        char c;
        while (true)
        {
            std::cin >> c;
            if (c == 'y')
            {
                res = 1;	// hit
                break;
            }
            else if (c == 'n')
            {
                res = 0;	// stick
                break;
            }
        }
    }
    else if (kind == 1)	//Sydney
    {
        if (getScore() > 11)
            res = 0;	// stick
        else
            res = 1;	// hit
    }
    else if (kind == 2) //Alex
    {
        if (getScore() < 21)
            res = 1;	// hit
        else
            res = 0;	// stick
    }
    else //Basic
    {
        int score = getScore();
        if (score >= 17)
            res = 0;			// stick
        else if (score >= 13 && score <= 16)
        {
            if (dealerCard.getNum() >= 2 && dealerCard.getNum() <= 6)
                res = 0;		// stick
            else
                res = 1;		// hit
        }
        else if (score == 12)
        {
            if (dealerCard.getNum() >= 4 && dealerCard.getNum() <= 6)
                res = 0;		// stick
            else
                res = 1;		// hit
        }
        else
            res = 1;
    }

    if (res == 0)
        std::cout << getName() << " sticks!" << std::endl;
    else
        std::cout << getName() << " hits!" << std::endl;
    return res;
}

int Player::checkResult(int dealerScore)	// if dealerScore is 0, Blackjack
{
    if (surrendered)
    {
        std::cout << getName() << " surrendered - " << bank_roll << "+" << (int)round(bet_money / 2.0) << std::endl;
        bank_roll += (int)round(bet_money / 2.0); // If surrendered and lost will get half of the money back
    }
    if (dealerScore == 0)	// dealer is Blackjack
    {
        int res = 0;
        if (checkBlackjack())
        {
            std::cout << getName() << " pushes - " << bank_roll << "+" << bet_money << std::endl;
            bank_roll += bet_money;
            res = 0;
        }
        else
        {
            std::cout << getName() << " loses - " << bank_roll << std::endl;
            res = -1;
        }
        if (insurance != 0)
        {
            std::cout << getName() << "insurance bet($" << insurance << ") - " << bank_roll + insurance * 2 << std::endl;
            bank_roll += insurance * 2;
        }
        return res;
    }

    if (checkBlackjack())	// If Player has Blackjack
    {
        if (blackjack65)
        {
            std::cout << getName() << " Blackjack - " << bank_roll << "+" << (int)round((bet_money / 6.0) * 5) << std::endl;
            bank_roll += (int)round(bet_money / 6.0 * 5);
        }
        else
        {
            std::cout << getName() << " Blackjack - " << bank_roll << "+" << (int)round((bet_money / 3.0) * 2) << std::endl;
            bank_roll += (int)round((bet_money / 3.0 )* 2);
        }
        return 1;
    }

    if (getScore() > 21)
    {
        std::cout << getName() << " loses - " << bank_roll << std::endl;
        return -1;
    }
    else if (dealerScore > 21)
    {
        std::cout << getName() << " wins - " << bank_roll << "+" << bet_money * 2 << std::endl;
        bank_roll += bet_money * 2;
        return 1;
    }
    else if (getScore() == dealerScore)
    {
        std::cout << getName() << " pushes - " << bank_roll << "+" << bet_money << std::endl;
        bank_roll += bet_money;
        return 0;
    }
    else if (getScore() < dealerScore)
    {
        std::cout << getName() << " loses - " << bank_roll << std::endl;
        return -1;
    }
    else
    {
        std::cout << getName() << " wins - " << bank_roll << "+" << bet_money * 2 << std::endl;
        bank_roll += bet_money * 2;
        return 1;
    }
}